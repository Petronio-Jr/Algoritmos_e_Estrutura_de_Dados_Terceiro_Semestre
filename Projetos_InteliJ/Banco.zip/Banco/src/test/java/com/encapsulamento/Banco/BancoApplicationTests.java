package com.encapsulamento.Banco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
